use LetMeFinish
GO

--scenarios 0 are all lock reviews if demo 2 not done

-------------------------------------------------
-- Scenario 0:  (*) Reader 
--              Locks held in read READ COMMITTED Tran
-------------------------------------------------

if @@trancount > 0 ROLLBACK --make sure there's no open transactions
SET TRANSACTION ISOLATION LEVEL READ COMMITTED
BEGIN TRANSACTION

SELECT *
FROM   Demo.SingleTable
GO

--stop - Show _LockViewer results

ROLLBACK 
GO

-------------------------------------------------
-- Scenario 0b:  (*) Reader 
--              Locks held in read REPEATABLE READ Tran
-------------------------------------------------

if @@trancount > 0 ROLLBACK --make sure there's no open transactions
SET TRANSACTION ISOLATION LEVEL REPEATABLE READ
BEGIN TRANSACTION

SELECT *
FROM   Demo.SingleTable
GO

--stop - Show _LockViewer results

ROLLBACK 
GO

-------------------------------------------------
-- Scenario 1:  (*) Reader
--              In tightest Isolation Level, can Reader block Reader?
-------------------------------------------------

if @@trancount > 0 ROLLBACK --make sure there's no open transactions
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
BEGIN TRANSACTION

SELECT *
FROM   Demo.SingleTable
GO

--stop,  then run other query

ROLLBACK 
GO

----------------------------------------------------------------
-- Scenario 2:  (*) Reader (1) Versus Reader (2) WITH XLOCK hint
--				Show that XLOCK may be ignored for clean page
----------------------------------------------------------------
if @@trancount > 0 ROLLBACK --make sure there's no open transactions
checkpoint; --forces a flush to disk so all pages are clean since we have no activity
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
BEGIN TRANSACTION

SELECT *
FROM   Demo.SingleTable WITH (XLOCK)
GO

--stop, show lock viewer

ROLLBACK 
GO

-------------------------------------------------
-- Scenario 3:  (*) Writer (1) Reader (2)
--				show how an update effects readers
-------------------------------------------------

--using READ COMMITTED because it is typical, and writers
--generally work the same in the different levels
if @@trancount > 0 ROLLBACK --make sure there's no open transactions
SET TRANSACTION ISOLATION LEVEL READ COMMITTED
BEGIN TRANSACTION

UPDATE Demo.SingleTable
SET    Value = UPPER(Value)
WHERE  Value = 'Fred'
GO

--stop

ROLLBACK 
GO

/* Add UNIQUE constraint to SingleTable
ALTER TABLE Demo.SingleTable 
   ADD CONSTRAINT AKsingleTable UNIQUE(Value)
*/

-------------------------------------------------
-- Scenario 4:  (*) Writer (1) Reader (2)
--			Show how things work when we update and then add a row
-------------------------------------------------
if @@trancount > 0 ROLLBACK --make sure there's no open transactions
SET TRANSACTION ISOLATION LEVEL READ COMMITTED
BEGIN TRANSACTION

--part 1
UPDATE Demo.SingleTable
SET    Value = UPPER(Value)
WHERE  Value <> 'Fred'
GO

--stop

--part 2
INSERT INTO Demo.SingleTable (Value)
VALUES ('AlternateFred'),('AlternateBarney')

--stop

ROLLBACK 
GO

---------------------------------------------------
---- Scenario 5:  (*) Reader (1) Writer (2)
----				Show effects a reader can have on writers, if any :)
----				Start with READ COMMITTED

--CUT FOR TIME: READ COMMITTED holds no locks (in essense, a RC isolalation
--                             level query can't hurt others after commpletion)
---------------------------------------------------
--if @@trancount > 0 ROLLBACK --make sure there's no open transactions
--SET TRANSACTION ISOLATION LEVEL READ COMMITTED
--BEGIN TRANSACTION

----part 1
--SELECT * 
--FROM   Demo.SingleTable
--WHERE  Value = 'Fred'
--GO

----stop

----part 2
--SELECT * 
--FROM   Demo.SingleTable
--WHERE  Value <> 'Fred'
--GO

----stop then go run the insert

--ROLLBACK 
--GO

-------------------------------------------------
-- Scenario 6:  (*) Reader (1) Writer (2)
--				Show how changes to the table coexist with 
--              REPEATABLE READs
-------------------------------------------------
if @@trancount > 0 ROLLBACK --make sure there's no open transactions
SET TRANSACTION ISOLATION LEVEL REPEATABLE READ
BEGIN TRANSACTION

--part 1
SELECT * 
FROM   Demo.SingleTable
GO

--stop

--part 2
SELECT *, case when value like 'Alternate%' then 'New' else '' end  status
FROM   Demo.SingleTable
GO

--stop, then go back to change rows

ROLLBACK 
GO

--reset
DELETE FROM Demo.SingleTable
where Value in ('AlternateFred','AlternateBarney')
GO

---------------------------------------------------
---- Scenario 7:  (*) Reader (1) Writer (2)
----				Show what the serializable tran doesn't allow
--
--CUT FOR TIME: SERIALIZABLE DOESN'T ALLOW ANY MODIFICIATION
---------------------------------------------------
--if @@trancount > 0 ROLLBACK --make sure there's no open transactions
--SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
--BEGIN TRANSACTION

--SELECT * 
--FROM   Demo.SingleTable
--GO

----stop

--ROLLBACK 
--GO

-------------------------------------------------
-- Scenario 8:  Foreign Keys and Isolation Levels
--				Show locks that are caused by FK in READ COMMITTED
-------------------------------------------------
if @@trancount > 0 ROLLBACK --make sure there's no open transactions
SET TRANSACTION ISOLATION LEVEL READ COMMITTED
BEGIN TRANSACTION

--note: personId is an FK
INSERT INTO Demo.Interaction (Subject, Message, 
						InteractionTime, PersonId)
VALUES ('Hello','Hello There',SYSDATETIME(),1)

--stop and show locks, then show update to Demo.Person

---then try to insert another row
INSERT INTO Demo.Interaction (Subject, Message, InteractionTime, PersonId)
VALUES ('Hello','Hello There',SYSDATETIME(),2)

ROLLBACK 
GO

-------------------------------------------------
-- Scenario 9:  Foreign Keys and Isolation Levels
--              USING SERIALIZABLE
-------------------------------------------------

if @@trancount > 0 ROLLBACK --make sure there's no open transactions
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
BEGIN TRANSACTION

INSERT INTO Demo.Interaction(Subject, Message, InteractionTime, PersonId)
VALUES ('Hello','Hello There',SYSDATETIME(),1)

ROLLBACK 
GO

-------------------------------------------------
-- Scenario 10:  Foreign Keys and Isolation Levels
-------------------------------------------------

if @@trancount > 0 ROLLBACK --make sure there's no open transactions
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
BEGIN TRANSACTION

DELETE FROM Demo.Person
WHERE  Name = 'Arnold'

--stop, show locks 

ROLLBACK 
GO

-------------------------------------------------
-- Scenario 11:  (*) Writer (1) Reader (2)
--			Show READ COMMITTED SNAPSHOT
-------------------------------------------------
if @@trancount > 0 ROLLBACK --make sure there's no open transactions

--kills all other connections
ALTER DATABASE  LetMeFinish
 	SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
GO
ALTER DATABASE LetMeFinish
SET READ_COMMITTED_SNAPSHOT ON --changes to allow snapshot for read committed transactions
GO
ALTER DATABASE  LetMeFinish
 	SET MULTI_USER;
GO

--stop

SET TRANSACTION ISOLATION LEVEL READ COMMITTED
BEGIN TRANSACTION

--part 1
UPDATE Demo.SingleTable
SET    Value = UPPER(Value)
WHERE  Value <> 'Fred'
GO

--stop

--part 2
INSERT INTO Demo.SingleTable (Value)
VALUES ('AlternateFred2'),('AlternateBarney2')

--stop

COMMIT
GO


/* Add read committed snapshot setting to db
--change other connection to different tb

ALTER DATABASE LetMeFinish
SET READ_COMMITTED_SNAPSHOT OFF
GO
*/



-------------------------------------------------
-- Scenario 12:  Deadlock
--			Show common deadlock scenario
-------------------------------------------------
if @@trancount > 0 ROLLBACK --make sure there's no open transactions
SET DEADLOCK_PRIORITY HIGH --This will be the more likely coonection to be saved
SET TRANSACTION ISOLATION LEVEL READ COMMITTED
BEGIN TRANSACTION

--part 1

UPDATE Demo.Person
SET    Name = LOWER(Name)
WHERE  Name = 'Fred'

--stop, go to other connection

--part 2

UPDATE Demo.Person
SET    Name = UPPER(Name)
WHERE  Name = 'Arnold'

--stop, back go to other connection to cause deadlock

ROLLBACK