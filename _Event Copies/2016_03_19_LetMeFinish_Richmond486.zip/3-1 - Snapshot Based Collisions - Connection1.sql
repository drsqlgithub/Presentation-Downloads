use LetMeFinish
GO

-------------------------------------------------
-- Scenario: 1 (*) Reader (1) Versus Reader (2)
--		After just adding the tables
-------------------------------------------------

SET TRANSACTION ISOLATION LEVEL READ COMMITTED
BEGIN TRANSACTION

SELECT *
FROM   Demo_Mem.SingleTable WITH (SNAPSHOT) --by default need isolation level hint
GO

--show lock viewer, no locks at all... 

ROLLBACK --I will always rollback/commit so we reset no matter how many transactions have been committed
GO


-------------------------------------------------
-- Scenario: 1a (*) Reader (1) Versus Reader (2)
--		SHOW DB setting that allows you to not set the 
--	    isolation level in the query
-------------------------------------------------

ALTER DATABASE LetMeFinish
  SET MEMORY_OPTIMIZED_ELEVATE_TO_SNAPSHOT ON
GO

SET TRANSACTION ISOLATION LEVEL READ COMMITTED
BEGIN TRANSACTION
GO

SELECT *
FROM   Demo_Mem.SingleTable --WITH (SNAPSHOT)
GO

COMMIT 
GO

--in examples, I want to show isolation level explicitly and use the engine
--to make sure I do
ALTER DATABASE LetMeFinish
 SET MEMORY_OPTIMIZED_ELEVATE_TO_SNAPSHOT OFF


--I will leave it as obvious that readers don't block readers in MVCC any more than
--using locks

-------------------------------------------------
-- Scenario 2:  (*) Writer (1) Reader (2)
--		In SNAPSHOT Isolation level, show that the result is the same 
--      regardless of who commit first
-------------------------------------------------
if @@trancount > 0 ROLLBACK --make sure there's no open transactions
SET TRANSACTION ISOLATION LEVEL READ COMMITTED
BEGIN TRANSACTION

UPDATE Demo_Mem.SingleTable WITH (SNAPSHOT)
SET    Value = UPPER(Value)
WHERE  Value = 'Fred'
GO

--stop

COMMIT 
GO

--Reset, before running scenario 3
UPDATE Demo_Mem.SingleTable WITH (SNAPSHOT)
SET    Value = 'Fred'
WHERE  Value = 'Fred'
GO



-------------------------------------------------
-- Scenario 3:  (*) Writer (1) Reader (2)
--			Show effects of the writer on the reader in REPEATABLE READ
-------------------------------------------------
if @@trancount > 0 ROLLBACK
SET TRANSACTION ISOLATION LEVEL READ COMMITTED
BEGIN TRANSACTION

UPDATE Demo_Mem.SingleTable WITH (SNAPSHOT)
SET    Value = UPPER(Value)
WHERE  Value = 'Fred'
GO

SELECT *
FROM   Demo_Mem.SingleTable WITH (SNAPSHOT)
WHERE  Value = 'Fred'
--stop

COMMIT --commit this connection first... 
GO

--Reset
UPDATE Demo_Mem.SingleTable WITH (SNAPSHOT)
SET    Value = 'Fred'
WHERE  Value = 'Fred'
GO


-------------------------------------------------
-- Scenario 4:  (*) Writer (1) Reader (2)
--			Show effects of the writer on the reader
--          not using an index, still with reader in REPEATABLE READ
-------------------------------------------------
if @@trancount > 0 ROLLBACK
SET TRANSACTION ISOLATION LEVEL READ COMMITTED
BEGIN TRANSACTION

UPDATE Demo_Mem.SingleTable WITH (SNAPSHOT)
SET    Value = UPPER(Value)
WHERE  Value = 'Fred'
GO

--stop

COMMIT
GO

/* Add contraint, run 4 again
ALTER TABLE Demo_Mem.SingleTable 
	ADD CONSTRAINT AKsingleTable UNIQUE NONCLUSTERED(Value)
*/

--Reset
UPDATE Demo_Mem.SingleTable WITH (SNAPSHOT)
SET    Value = 'Fred'
WHERE  Value = 'Fred'
GO

---------------------------------------------------
---- Scenario 5:  (*) Reader (1) Writer (2)
----		show how the reader never changes in SNAPSHOT
---------------------------------------------------
--if @@trancount > 0 ROLLBACK
--SET TRANSACTION ISOLATION LEVEL READ COMMITTED
--BEGIN TRANSACTION

--SELECT * 
--FROM   Demo_Mem.SingleTable WITH (SNAPSHOT)

----stop

--SELECT * 
--FROM   Demo_Mem.SingleTable WITH (SNAPSHOT)
--COMMIT
--GO
--SELECT * 
--FROM   Demo_Mem.SingleTable WITH (SNAPSHOT)
--GO

----stop

----Reset
--UPDATE Demo_Mem.SingleTable WITH (SNAPSHOT)
--SET    Value = 'Fred'
--WHERE  Value = 'Fred'

--DELETE FROM Demo_Mem.SingleTable
--WHERE  Value IN ('AlternateFred','AlternateBarney')

-------------------------------------------------
-- Scenario 6:  (*) Reader (1) Writer (2)
--		show how the reader is affected by the writers
-------------------------------------------------
if @@trancount > 0 ROLLBACK
SET TRANSACTION ISOLATION LEVEL READ COMMITTED
BEGIN TRANSACTION

SELECT * 
FROM   Demo_Mem.SingleTable WITH (REPEATABLEREAD)
GO

--stop, run a batch on 2 and then commit

COMMIT
GO



--Reset
UPDATE Demo_Mem.SingleTable WITH (SNAPSHOT)
SET    Value = 'Fred'
WHERE  Value = 'Fred'

DELETE FROM Demo_Mem.SingleTable
WHERE  Value IN ('AlternateFred','AlternateBarney')

---------------------------------------------------
---- Scenario 7:  (*) Reader (1) Writer (2)
---------------------------------------------------

--SET TRANSACTION ISOLATION LEVEL READ COMMITTED
--BEGIN TRANSACTION

--SELECT * 
--FROM   Demo_Mem.SingleTable WITH (SERIALIZABLE)
--GO

----stop

--COMMIT
--GO

----reset
--DELETE FROM Demo_Mem.SingleTable
--WHERE  Value IN ('AlternateFred','AlternateBarney')

-------------------------------------------------
-- Scenario 8:  (*) Writer (1) Writer (2)
--		show what happens when two connections try to write
--		the same physical resource
-------------------------------------------------
if @@trancount > 0 ROLLBACK
SET TRANSACTION ISOLATION LEVEL READ COMMITTED
BEGIN TRANSACTION

UPDATE Demo_Mem.SingleTable WITH (SNAPSHOT)
SET    Value = 'Fred2'
WHERE  Value = 'Fred'

--stop

ROLLBACK
GO

-------------------------------------------------
-- Scenario 9:  (*) Writer (1) Writer (2)
--		show what happens when a key violation (based on the key we
--      added) occurs during the transaction. This is an example of
--      a logical resource until commit time. It is not checked until commit
-------------------------------------------------
if @@trancount > 0 ROLLBACK
SET TRANSACTION ISOLATION LEVEL READ COMMITTED
BEGIN TRANSACTION

INSERT INTO Demo_Mem.SingleTable(Value)
VALUES ('AlternateFred'),('AlternateBarney')
GO

select *
from   Demo_Mem.SingleTable  WITH (SNAPSHOT)

--stop

COMMIT
GO

DELETE FROM Demo_Mem.SingleTable
WHERE  Value IN ('AlternateFred', 'AlternateBarney')

-------------------------------------------------
-- Scenario 10:  Foreign Keys and Isolation Levels
--		Show how the FK reference works in SNAPSHOT isolation level
-------------------------------------------------
if @@trancount > 0 ROLLBACK
SET TRANSACTION ISOLATION LEVEL READ COMMITTED
BEGIN TRANSACTION

INSERT INTO Demo_Mem.Interaction WITH (SNAPSHOT) (Subject, Message, InteractionTime, PersonId)									
VALUES ('Hello','Hello There',SYSDATETIME(),1)
GO

--stop

SELECT *
FROM   Demo_Mem.Interaction WITH (SNAPSHOT)
WHERE  PersonId = 1


COMMIT 
GO

--reset
SET IDENTITY_INSERT Demo_Mem.Person ON
GO
INSERT INTO Demo_Mem.Person (PersonId, Name)
VALUES (1,'Fred')
GO
SET IDENTITY_INSERT Demo_Mem.Person OFF
GO


-------------------------------------------------
-- Scenario 11:  Foreign Keys and Isolation Levels
--		Show what happens when a non-key column is updates on a FK reference
-------------------------------------------------

if @@trancount > 0 ROLLBACK
SET TRANSACTION ISOLATION LEVEL READ COMMITTED
BEGIN TRANSACTION

INSERT INTO Demo_Mem.Interaction WITH (SNAPSHOT)
VALUES ('Hello','Hello There',SYSDATETIME(),1)
GO

--stop

SELECT *
FROM   Demo_Mem.Interaction WITH (SNAPSHOT)
WHERE  PersonId = 1

SELECT *
FROM   Demo_Mem.Person WITH (SNAPSHOT)
WHERE  PersonId = 1

--stop

COMMIT 
GO

--reset
UPDATE Demo_Mem.Person WITH (SNAPSHOT)
SET    Name = 'Fred'
WHERE  PersonId = 1