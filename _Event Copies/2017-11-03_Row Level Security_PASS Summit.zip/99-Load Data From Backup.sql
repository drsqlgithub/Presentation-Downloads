USE TestRowLevelSecurity_alt
GO
INSERT INTO Demo.Employee(EmployeeId,
                     EmployeeNumber,
                     ManagerId)
SELECT EmployeeId, EmployeeNumber, ManagerId
FROM   RLSSourceData.Demo.Employee
GO
INSERT INTO Demo.WidgetType(WidgetType,
                       ManagedByEmployeeId)
SELECT WidgetType, ManagedByEmployeeId
FROM    RLSSourceData.Demo.WidgetType
GO
INSERT INTO Demo.Widget(WidgetId,
                   WidgetName,
                   WidgetType)
SELECT WidgetId,WidgetName,WidgetType
FROM   RLSSourceData.Demo.Widget
GO