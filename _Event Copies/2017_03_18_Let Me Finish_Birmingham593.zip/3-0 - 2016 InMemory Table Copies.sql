use LetMeFinish
GO

drop table if exists demo_mem.SingleTable;
drop table if exists demo_mem.Interaction;
drop table if exists demo_mem.Person;
drop schema if exists demo_mem;
GO

create schema Demo_Mem
go
create  table Demo_Mem.SingleTable
(
	singleTableId int identity(1,1) CONSTRAINT PKsingleTable PRIMARY KEY NONCLUSTERED HASH  WITH (BUCKET_COUNT=100),
	value varchar(100) 
	,padding char(4000) --default (replicate('A',2000)) --NOT SUPPORTED
) WITH ( MEMORY_OPTIMIZED = ON );


insert into Demo_Mem.SingleTable (Value, Padding)
values  ('Fred'      ,REPLICATE('a',2000)),
		('Barney'	 ,REPLICATE('a',2000)),
		('Wilma'	 ,REPLICATE('a',2000)),
		('Betty'	 ,REPLICATE('a',2000)),
		('Mr_Slate'	 ,REPLICATE('a',2000)),
		('Slagstone' ,REPLICATE('a',2000)),
		('Gazoo'	 ,REPLICATE('a',4000)),
		('Hoppy'	 ,REPLICATE('a',4000)),
		('Schmoo'	 ,REPLICATE('a',4000)),
		('Slaghoople',REPLICATE('a',4000)),
		('Pebbles'	 ,REPLICATE('a',4000)),
		('BamBam'	 ,REPLICATE('a',4000)),
		('Rockhead'	 ,REPLICATE('a',4000)),
		('Arnold'	 ,REPLICATE('a',4000)),
		('ArnoldMom' ,REPLICATE('a',4000)),
		('Tex'		 ,REPLICATE('a',4000)),
		('Dino'		 ,REPLICATE('a',4000))

GO
create table Demo_Mem.Person
(
	PersonId int identity(1,1) CONSTRAINT PKPerson PRIMARY KEY  NONCLUSTERED HASH  WITH (BUCKET_COUNT=100),
	Name varchar(100) CONSTRAINT AKPerson UNIQUE NONCLUSTERED,
) WITH ( MEMORY_OPTIMIZED = ON );
GO
insert into Demo_Mem.Person (Name)
select value from Demo_Mem.SingleTable
GO
create table Demo_Mem.Interaction
(
	InteractionId int identity(1,1) CONSTRAINT PKInteraction PRIMARY KEY  NONCLUSTERED HASH  WITH (BUCKET_COUNT=100),
	Subject  nvarchar(20),
	Message  nvarchar(100),
	InteractionTime datetime2(0),
	PersonId int CONSTRAINT FKInteraction$References$Demo_Person REFERENCES Demo_Mem.Person(PersonId),
	CONSTRAINT AKInteraction UNIQUE NONCLUSTERED (PersonId, Subject,Message)
)  WITH ( MEMORY_OPTIMIZED = ON );
go
--add an insert first that loads other rows
INSERT INTO Demo_Mem.Interaction(Subject, Message, InteractionTime, PersonId)
VALUES ('Hello1','Hello There',SYSDATETIME(),10)
INSERT INTO Demo_Mem.Interaction(Subject, Message, InteractionTime, PersonId)
VALUES ('Hello2','Hello There',SYSDATETIME(),9)
INSERT INTO Demo_Mem.Interaction(Subject, Message, InteractionTime, PersonId)
VALUES ('Hello3','Hello There',SYSDATETIME(),8)
GO

