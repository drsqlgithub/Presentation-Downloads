/*

Code can be found at  http://drsql.org/presentations

If you want to contact me, DRSQL:
	DRSQL.org
	drsql@hotmail.com or louis@drsql.org
	Twitter:drsql


See you real soon!

*/