/*
Topics:

--Temporal Tables
--Row Level Security
--Dynamic Data Masking
--JSON
--Miscellaneous Treats 

Code can be found at  http://drsql.org/presentations

If you want to contact me, DRSQL:
	DRSQL.org
	drsql@hotmail.com or louis@drsql.org
	Twitter:drsql

Upcoming events of note:
	SQL Saturday Chattanooga: June 24, 2017 http://www.sqlsaturday.com/624/eventhome.aspx
	Music City Code: Jun 1-3, 2017 http://musiccitycode.com 
*/