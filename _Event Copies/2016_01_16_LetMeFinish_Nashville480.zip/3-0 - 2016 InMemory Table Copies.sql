use LetMeFinish
GO
--?can you block in a snapshot
create schema Demo_Mem
go
create  table Demo_Mem.SingleTable
(
	singleTableId int identity(1,1) CONSTRAINT PKsingleTable PRIMARY KEY NONCLUSTERED HASH  WITH (BUCKET_COUNT=100),
	value varchar(100) 
) WITH ( MEMORY_OPTIMIZED = ON );

insert into Demo_Mem.SingleTable
values  ('Fred'      ),
		('Barney'	 ),
		('Wilma'	 ),
		('Betty'	 ),
		('Mr_Slate'	 ),
		('Slagstone' ),
		('Gazoo'	 ),
		('Hoppy'	 ),
		('Schmoo'	 ),
		('Slaghoople'),
		('Pebbles'	 ),
		('BamBam'	 ),
		('Rockhead'	 ),
		('Arnold'	 ),
		('ArnoldMom' ),
		('Tex'		 ),
		('Dino'		 )
GO
create table Demo_Mem.Person
(
	PersonId int identity(1,1) CONSTRAINT PKPerson PRIMARY KEY  NONCLUSTERED HASH  WITH (BUCKET_COUNT=100),
	Name varchar(100) CONSTRAINT AKPerson UNIQUE NONCLUSTERED,
) WITH ( MEMORY_OPTIMIZED = ON );
GO
SET identity_insert Demo_Mem.Person ON
GO
insert into Demo_Mem.Person (PersonId, Name)
select PersonId, Name from Demo.Person
GO
SET identity_insert Demo_Mem.Person OFF
GO
create table Demo_Mem.Interaction
(
	InteractionId int identity(1,1) CONSTRAINT PKInteraction PRIMARY KEY  NONCLUSTERED HASH  WITH (BUCKET_COUNT=100),
	Subject  nvarchar(20),
	Message  nvarchar(100),
	InteractionTime datetime2(0),
	PersonId int CONSTRAINT FKInteraction$References$Demo_Person REFERENCES Demo_Mem.Person(PersonId),
	CONSTRAINT AKInteraction UNIQUE NONCLUSTERED (PersonId, Subject,Message)
)  WITH ( MEMORY_OPTIMIZED = ON );