/*
Topics:

--Row Level Security
-- -- Using 2017 Feature
-- -- -- Mechanics
-- -- -- Scaling
--	Using Legacy Tools
--Dynamic Data Masking 

Code can be found at  http://drsql.org/presentations

If you want to contact me, DRSQL:
	DRSQL.org  (Today's code and more located here via Dropbox links)
	drsql@hotmail.com or louis@drsql.org
	Twitter:drsql

Upcoming events of note:
	SQL Saturday Chattanooga: June 24, 2017 http://www.sqlsaturday.com/624/eventhome.aspx
	SQL Saturday Atlanta: July 15, 2017: http://www.sqlsaturday.com/652/eventhome.aspx
*/

SELECT 'Well can you?' AS [Can you read this?], @@version;