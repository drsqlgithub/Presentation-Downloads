/*
Topics (Enough to fill more than 1 hour):

--Row Level Security
--==================

-- Using 2016 Feature
	-- Mechanics
	-- Scaling
--Using Legacy Tools
--Dynamic Data Masking

Code can be found at  http://drsql.org/presentations

If you want to contact me, DRSQL:
	DRSQL.org  (Today's code and more located here via Dropbox links)
	drsql@hotmail.com or louis@drsql.org
	Twitter:drsql

User Groups for SQL:
	Chattanooga: spoc.pass.org (Last Friday of Month: Lunch)
	Nashville: nashville.pass.org (Last Tuesday of Month: Dinner)
	

*/

SELECT 'Well can you?' AS [Can you read this?], @@version;